select e1.*
from el.tbrtms_real_objs e1
inner join (select hous_id, max(contract_date) as deal_date
from el.tbrtms_real_objs group by hous_id) e2
on e2.hous_id = e1.hous_id and e2.deal_date = e1.contract_date;


select hous_id, max(contract_date) as deal_date
from el.tbrtms_real_objs
group by hous_id;



deal_amt, land_area, lawd_cm002_cd, rt006_cd, rt008_cd


deal_cd
hous_id
deal_amt
land_area
lawd_cm002_cd
rt006_cd
rt008_cd
contract_date





explain INSERT INTO EL.tel_appr_reward 		 
( 				  
	reward_seq 				
	, pnu
	, real_amt
	, real_date
	, geom	 
	,SIDO_CD
	,SGG_CD
	,EMD_CD
	,DR_CD
	,SABN
	,BOBN
	,BUBN
	,lawd_cm002_cd
	,rt008_cd
	,rt006_cd
	,real_year
	,addr2
)			
	SELECT 
		EL.TEL_APPR_REWARD_SEQ.NEXTVAL 	
		, A.hous_id
		, CAST(A.deal_amt as  bigint)
		, A.deal_date
		, CAST(A.wkb_geometry as geometry)
		,SUBSTRING(hous_id, 1, 2)
		,SUBSTRING(hous_id, 1, 5)
		,SUBSTRING(hous_id, 1, 8)
		,SUBSTRING(hous_id, 1, 10)
		,SUBSTRING(hous_id, 11, 1)
		,SUBSTRING(hous_id, 12, 4)
		,SUBSTRING(hous_id, 16, 4)		
		, A.lawd_cm002_cd
		, A.rt008_cd
		, A.rt006_cd
		, SUBSTRING(deal_date, 1, 4)
		, CASE WHEN D.EMD_NM is null THEN '' ELSE ('' || d.EMD_NM) END 
				  || CASE WHEN E.ri_nm is null THEN '' ELSE (' ' || E.ri_nm) END 
				  || CASE SUBSTR(A.hous_id, 11,1) WHEN '2' THEN ' 산' ELSE '' END 
				  || CASE SUBSTR(A.hous_id, 12,4) WHEN '0000' THEN '' ELSE ' ' || TO_NUMBER(SUBSTR(A.hous_id, 12,4)) END 
				  || CASE SUBSTR(A.hous_id, 16,4) WHEN '0000' THEN '' ELSE '-' || TO_NUMBER(SUBSTR(A.hous_id, 16,4)) END 
				  || CASE WHEN f.jimok_nm is null THEN '' ELSE (' ' || f.jimok_nm) END AS PNU_ADDR
from 
	( select * from ( select wkb_geometry, pnu  from public.cla_lppacbnd_kl_20240201 ) B  
	inner join  
	(  
		select  
			hous_id    
			,  CASE  
				WHEN land_area > 0 then round((deal_amt/land_area)/1000, 0)    
				ELSE 0  
				END	as deal_amt    
			 , cast(contract_date as text) as deal_date  
			 , lawd_cm002_cd     
			 , rt008_cd     
			 , rt006_cd     
			 , ROW_NUMBER() OVER(PARTITION BY hous_id ORDER BY deal_cd DESC) AS RN    
		from leibes.tbrtms_real_objects
		where to_number(deal_cd) > 20200000000000000000000 AND round((deal_amt/land_area)/1000, 0) > 0
		) A   
		on (a.rn =1 and a.deal_amt >0 and b.pnu = a.hous_id)
	) A 
 LEFT OUTER JOIN ( SELECT EMD_NM, EMD_CD FROM PUBLIC.caa_lpaaemd_kl_20240201 ) D ON ( SUBSTR( a.hous_id, 1, 8 ) = D.EMD_CD )  
 LEFT OUTER JOIN ( SELECT RI_NM, RI_CD FROM PUBLIC.caa_lpaari_kl_20240201 ) E ON ( SUBSTR( a.hous_id, 1, 10 ) = E.RI_CD )  
 LEFT OUTER JOIN ( SELECT s_desc2 AS JIMOK_NM, s_code FROM el.tel_s_code WHERE p_code = 'JIMOK_CD' ) f ON ( A.lawd_cm002_cd = f.s_code )
 ON CONFLICT (pnu) DO  		
 	UPDATE SET  				  
 		real_amt = excluded.real_amt				
 		, real_date = excluded.real_date				
 		, rt008_cd = excluded.rt008_cd				
 		, lawd_cm002_cd = excluded.lawd_cm002_cd			
 		, rt006_cd =  excluded.rt006_cd			
 		, real_year = excluded.real_year;



-- 부동산 테이블에서 거래날짜가 삭제돼서 존재하지 않는 경우 지가 테이블에서도 삭제
explain analyze
delete 
from el.tel_appr_reward a
using (select hous_id, max(contract_date) as contract_date from leibes.tbrtms_real_objects group by hous_id) b
where 
	a.pnu = '1138010800101890044' -- 임시 테스트용
	and a.real_date is not null
	and a.real_year is not null
  and contact_amt_t is null
  and contact_year is null
	and a.pnu = b.hous_id
  and a.real_date != b.contract_date


  
javac C:\Users\user\Documents\updateFiles\AuthenticInterceptor.java
javac CommonController.java
javac Tab1Controller.java
javac Tab1DAO.java
javac Tab1Service.java
javac Tab1ServiceImpl.java