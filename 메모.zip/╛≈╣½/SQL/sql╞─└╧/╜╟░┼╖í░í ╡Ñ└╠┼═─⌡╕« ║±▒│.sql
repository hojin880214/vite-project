INSERT INTO scehma.table 		 
( 				  
	seq 				
	, num
	, money
	, date
	, gr	 
	,code1
	,code2
	,code3
	,code4
	,number1
	,number2
	,number3
	,b_code1
	,r_code8
	,r_code6
	,year
	,ad2
)			
	SELECT 
		scehma.SEQ.NEXTVAL 																														
		, A.user_id																													
		, CAST(A.amount1 as  bigint)																													
		, A.date1																													
		, CAST(A.wg as ground)																													
		,SUBSTRING(user_id, 1, 2)																													
		,SUBSTRING(user_id, 1, 5)																													
		,SUBSTRING(user_id, 1, 8)																													
		,SUBSTRING(user_id, 1, 10)																													
		,SUBSTRING(user_id, 11, 1)																													
		,SUBSTRING(user_id, 12, 4)																													
		,SUBSTRING(user_id, 16, 4)																															
		, A.b_code1																													
		, A.r_code8																													
		, A.r_code6																													
		, SUBSTRING(date1, 1, 4)																													
		, CASE WHEN D.e_number1 is null THEN '' ELSE ('' || d.e_number1) END 																													
				  || CASE WHEN E.r_number1 is null THEN '' ELSE (' ' || E.r_number1) END 
				  || CASE SUBSTR(A.user_id, 11,1) WHEN '2' THEN ' 산' ELSE '' END 
				  || CASE SUBSTR(A.user_id, 12,4) WHEN '0000' THEN '' ELSE ' ' || TO_NUMBER(SUBSTR(A.user_id, 12,4)) END 
				  || CASE SUBSTR(A.user_id, 16,4) WHEN '0000' THEN '' ELSE '-' || TO_NUMBER(SUBSTR(A.user_id, 16,4)) END 
				  || CASE WHEN f.j_code1 is null THEN '' ELSE (' ' || f.j_code1) END AS num_ADDR
from 
	( select *  from  ( select wg, num  from public.table_d ) B  
	inner join  
	(  
		select  
			user_id    
			,  CASE  
				WHEN r_code6 = '1' and place1 > 0 then round((amount1/place1)/1000, 0)  
				WHEN r_code6 = '3' and place2 > 0 then round((amount1/place2)/1000, 0)  
				ELSE 0  
				END	as amount1    
			 , substring(dd_code1, 1, 8) as date1    
--			 , rt302_cd     
			 , b_code1     
			 , r_code8     
			 , r_code6     
			 , ROW_NUMBER() OVER(PARTITION BY user_id ORDER BY dd_code1 DESC) AS RN    
		from schema2.table2    
		where r_code6 = '1' and amount1 > 0 and round((amount1/place1)/1000, 0) > 0  
		) A   
		on (a.rn =1 and a.amount1 >0 and b.num = a.user_id)
	) A 
 LEFT OUTER JOIN ( SELECT e_number1, code3 FROM PUBLIC.table3 ) D ON ( SUBSTR( a.user_id, 1, 8 ) = D.code3 )  
 LEFT OUTER JOIN ( SELECT r_number1, rrr_code FROM PUBLIC.table4 ) E ON ( SUBSTR( a.user_id, 1, 10 ) = E.rrr_code )  
 LEFT OUTER JOIN ( SELECT spde1 AS j_code1, s_code FROM scehma.tel_s_code WHERE p_code = 'JIMOK_CD' ) f ON ( A.b_code1 = f.s_code )
 ON CONFLICT (num) DO  		
 	UPDATE SET  				  
 		money = excluded.money				
 		, date = excluded.date				
 		, r_code8 = excluded.r_code8				
 		, b_code1 = excluded.b_code1			
 		, r_code6 =  excluded.r_code6			
 		, year = excluded.year;



