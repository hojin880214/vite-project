1. 언젠가 hous_id가 1138010800101890044인 2022년 데이터가 insert 됐다.
2. 그런데 어떤 시점에 leibes.tbrtms_real_objects의 1138010800101890044, 2022 데이터가 삭제되거나 변경됐다(이력추적 x).
3. EL.tel_appr_reward 갱신 로직상 deal_cd로 현재 시점을 지정해서 insert-update(upsert) 한다.
4. 현재 시점은 202404 정도인데, 2022년, 2007년 데이터에 대해선 변동이 발생해도 update가 되지 않는다.
5. deal_cd >= '20240200000000000000000' 조건에 2022, 2007년 등 과거 시점은 조회가 되지 않고, 그래서 pnu 충돌(select 조회값과 EL.tel_appr_reward 간 pnu)이 없어서 과거 시점 데이터 대해선 갱신이 되지 않는다.
6. 1138010800101890044 데이터에서 2007이 나중에 추가되었고, 2022가 삭제됐다면 그게 EL.tel_appr_reward엔 반영되지 않는다.



explain INSERT INTO EL.tel_appr_reward
( 				  
	reward_seq 				
	, pnu
	, real_amt
	, real_date
	, geom	 
	,SIDO_CD
	,SGG_CD
	,EMD_CD
	,DR_CD
	,SABN
	,BOBN
	,BUBN
	,lawd_cm002_cd
	,rt008_cd
	,rt006_cd
	,real_year
	,addr2
)			
	SELECT 
		EL.TEL_APPR_REWARD_SEQ.NEXTVAL 	
		, A.hous_id
		, CAST(A.deal_amt as  bigint)
		, A.deal_date
		, CAST(A.wkb_geometry as geometry)
		,SUBSTRING(hous_id, 1, 2)
		,SUBSTRING(hous_id, 1, 5)
		,SUBSTRING(hous_id, 1, 8)
		,SUBSTRING(hous_id, 1, 10)
		,SUBSTRING(hous_id, 11, 1)
		,SUBSTRING(hous_id, 12, 4)
		,SUBSTRING(hous_id, 16, 4)		
		, A.lawd_cm002_cd
		, A.rt008_cd
		, A.rt006_cd
		, SUBSTRING(deal_date, 1, 4)
		, CASE WHEN D.EMD_NM is null THEN '' ELSE ('' || d.EMD_NM) END 
				  || CASE WHEN E.ri_nm is null THEN '' ELSE (' ' || E.ri_nm) END 
				  || CASE SUBSTR(A.hous_id, 11,1) WHEN '2' THEN ' 산' ELSE '' END 
				  || CASE SUBSTR(A.hous_id, 12,4) WHEN '0000' THEN '' ELSE ' ' || TO_NUMBER(SUBSTR(A.hous_id, 12,4)) END 
				  || CASE SUBSTR(A.hous_id, 16,4) WHEN '0000' THEN '' ELSE '-' || TO_NUMBER(SUBSTR(A.hous_id, 16,4)) END 
				  || CASE WHEN f.jimok_nm is null THEN '' ELSE (' ' || f.jimok_nm) END AS PNU_ADDR
from 
	( select * from ( select wkb_geometry, pnu  from public.cla_lppacbnd_kl_20240201 ) B  
	inner join  
	(  
		select  
			hous_id    
			,  CASE  
				WHEN land_area > 0 then round((deal_amt/land_area)/1000, 0)    
				ELSE 0  
				END	as deal_amt    
			 , substring(deal_cd, 1, 8) as deal_date  
			 , lawd_cm002_cd     
			 , rt008_cd     
			 , rt006_cd     
			 , ROW_NUMBER() OVER(PARTITION BY hous_id ORDER BY deal_cd DESC) AS RN    
		from leibes.tbrtms_real_objects
		where rt006_cd = '1' and to_number(deal_cd) >= 20020000000000000000000 AND round((deal_amt/land_area)/1000, 0) > 0 
		) A   
		on (a.rn =1 and a.deal_amt >0 and b.pnu = a.hous_id)
	) A 
 LEFT OUTER JOIN ( SELECT EMD_NM, EMD_CD FROM PUBLIC.caa_lpaaemd_kl_20240201 ) D ON ( SUBSTR( a.hous_id, 1, 8 ) = D.EMD_CD )  
 LEFT OUTER JOIN ( SELECT RI_NM, RI_CD FROM PUBLIC.caa_lpaari_kl_20240201 ) E ON ( SUBSTR( a.hous_id, 1, 10 ) = E.RI_CD )  
 LEFT OUTER JOIN ( SELECT s_desc2 AS JIMOK_NM, s_code FROM el.tel_s_code WHERE p_code = 'JIMOK_CD' ) f ON ( A.lawd_cm002_cd = f.s_code )
 ON CONFLICT (pnu) DO  		
 	UPDATE SET  				  
 		real_amt = excluded.real_amt				
 		, real_date = excluded.real_date				
 		, rt008_cd = excluded.rt008_cd				
 		, lawd_cm002_cd = excluded.lawd_cm002_cd			
 		, rt006_cd =  excluded.rt006_cd			
 		, real_year = excluded.real_year;
 		