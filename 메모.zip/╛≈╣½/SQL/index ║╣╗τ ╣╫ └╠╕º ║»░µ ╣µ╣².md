
### Index 복사 방법

1. 스키마와 테이블 입력
```sql
SELECT
  indexname,
  indexdef
FROM
  pg_indexes
WHERE
  schemaname = 'public'
  AND tablename = 'products';
```

2. 결과값에서 indexdef 컬럼 복사
```sql
CREATE UNIQUE INDEX products_pkey ON products USING btree (id);
CREATE INDEX products_name_idx ON products USING btree (name);
```

3. ON 부분에 대상 테이블명으로 변경
```sql
CREATE UNIQUE INDEX products_pkey -- 인덱스 이름
	ON new_products -- 대상 테이블 이름
	USING btree (id) -- 인덱스 사용할 컬럼
;
CREATE INDEX products_name_idx ON new_products USING btree (name);
```



### 인덱스 이름 변경

- 스키마 입력해야함
```sql
ALTER INDEX old_index_name RENAME TO new_index_name;
```