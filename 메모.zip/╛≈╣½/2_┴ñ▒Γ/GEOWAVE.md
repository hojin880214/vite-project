
### Geowave 명령어

gw_layerlist : 레이어 리스트 확인
`gw_layerlist | grep caa_lpaasgg_kl_20240301`

gw_checkmeta : 레이어 메타정보 확인
`gw_checkmeta caa_lpaasgg_kl_20240301`

