#hotspot #빅데이터 #핫스팟
## hotspot 작업 메모


데이터를 운영 DB에서 GW로 적재
hadoop 작업 확인방법
- source 테이블과 hive의 target 개수 카운트 하여 일치하는지 확인
```
ex)
hadoop jar BigdataSync_bs.jar conf:conf/BigdataSync_park.properties source:lrms_common_bigdata target:lrms_common_dummy2 DB2GW 

db   :  select count(*) from lrms_common_bigdata;
hive :  select count(*) from lrms_common_dummy2;
```

hadoop작업 안 될 경우 인프라 담당자(임재선 차장님) 문의


### 실거래가/ 전월세 Hotspot 갱신 후 확인 방법

1. 부동산정보뱅크 접속
2. 상단 빅데이터 공간분석 탭
3. 실거래가 분석 / 전월세 분석 클릭
4. 분석실행 클릭
5. 진행상태 탭의 조회 클릭
6. 반영한 월의 데이터 나오는지 확인


#### 에러

