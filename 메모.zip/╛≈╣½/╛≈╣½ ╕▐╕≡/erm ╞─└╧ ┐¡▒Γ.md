erm파일 열기

이클립스에서 ERMaster 플러그인 설치하면 해결



파일 명 ex) `org.insightech.er_1.0.0.v20150619-0219.jar`
플러그인 설치 막힌 경우 파일을 아래 경로로 복사
```
C:\dev4\eGovFrameDev-3.10.0-64bit\eclipse\plugins
```

