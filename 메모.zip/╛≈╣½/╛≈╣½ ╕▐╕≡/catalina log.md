
# 시스템 로그 백업
### catalina.log 경로
```
/home/cloud-user/jws-5.7/tomcat/logs
```


### 공유폴더 경로

- WAS 01(243)
```
\\172.23.187.40\klhsb_share\00 공유폴더\2023_시스템로그백업\07_1.EL_지가심사\was01
```

- WAS 02(244)
```
\\172.23.187.40\klhsb_share\00 공유폴더\2023_시스템로그백업\07_1.EL_지가심사\was02
```

