
## BigdataSync_park.properties,  BigdataSync_park2.properties 변경
db.datastore.host=`172.18.2.197` -> `172.18.2.198` 로 변경

```
# BigdataSync_park2.properties 파일

#postgis datastore datasource
ds.datastore.type=POSTGIS
ds.datastore.host=172.18.2.198
ds.datastore.port=5444
ds.datastore.db_name=klhsb
ds.datastore.db_user=enterprisedb
ds.datastore.db_passwd=ppas0411
ds.datastore.db_schema=public
#ds.datastore.db_schema=bs

#to geowave datasource
ds.geowave.type=GEOWAVE
ds.geowave.host=172.23.187.58
ds.geowave.port=54555
ds.geowave.hdfspath=/klhsb/input/

#data mppaing filtering - tra_eclynd_eg
#mf.tra_eclynd_eg.colmap.acls=ucode;string
#mf.tra_eclynd_eg.filter.acls=acls = 1;string

#data mppaing filtering - tra_fs_fg
#mf.tra_fs_fg.colmap.acls=ucode;string
mf.tra_fs_fg.colmap.signgucd=sgg_cod;string
mf.tra_fs_fg.filter.acls=acls >= 5;string

#data mppaing filtering - tra_grtnd_eg
#mf.tra_grtnd_eg.colmap.gradse=ucode;string
mf.tra_grtnd_eg.colmap.signgucd=sgg_cod;string
mf.tra_grtnd_eg.filter.gradse=gradse >= 8;string
```
