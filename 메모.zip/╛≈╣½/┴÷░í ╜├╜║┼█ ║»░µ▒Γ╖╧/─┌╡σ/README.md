

### 배포 시 서버 재시작(서버 재기동)

1. 로그 확인
```bash
tail -f /home/cloud-user/jws-5.7/tomcat/logs/catalina.out
```

2. 스크립트 경로 이동
```bash
cd /home/cloud-user/jws-5.7/tomcat/bin
```

3. tomcat 상태 확인
```bash
ps -ef | grep tomcat
```

```bash
// tomcat 실행 중
cloud-u+  2780     1  0 Jun10 ?        00:13:30 //bin/java -Djava.util.logging.config.file=/home/cloud-user/jws-5.7/tomcat/conf/logging.properties -Djava.util.logging.manager=org.apache.juli.ClassLoaderLogManager -Djdk.tls.ephemeralDHKeySize=2048 -Djava.protocol.handler.pkgs=org.apache.catalina.webresources -Dorg.apache.catalina.security.SecurityListener.UMASK=0027 -Dignore.endorsed.dirs= -classpath /home/cloud-user/jws-5.7/tomcat/bin/bootstrap.jar:/home/cloud-user/jws-5.7/tomcat/bin/tomcat-juli.jar -Dcatalina.base=/home/cloud-user/jws-5.7/tomcat -Dcatalina.home=/home/cloud-user/jws-5.7/tomcat -Djava.io.tmpdir=/home/cloud-user/jws-5.7/tomcat/temp org.apache.catalina.startup.Bootstrap start
cloud-u+ 17118 17079  0 15:09 pts/0    00:00:00 tail -f /home/cloud-user/jws-5.7/tomcat/logs/catalina.out
cloud-u+ 17384 17331  0 15:13 pts/1    00:00:00 grep --color=auto tomcat


// tomcat 정지
cloud-u+ 13156 13111  0 15:18 pts/0    00:00:00 tail -f /home/cloud-user/jws-5.7/tomcat/logs/catalina.out
cloud-u+ 13333 13182  0 15:19 pts/1    00:00:00 grep --color=auto tomcat
```

4. 서버 정지
```bash
./shutdown.sh
```

5. 서버 실행
```bash
./startup.sh
```

---

로컬 테스트용 url
```
http://172.23.187.110:8089/?_uid=fcDYJNqkn9bJJxRr5yA23PquGgA2l6bt03aElDG1QG4%3D
```

