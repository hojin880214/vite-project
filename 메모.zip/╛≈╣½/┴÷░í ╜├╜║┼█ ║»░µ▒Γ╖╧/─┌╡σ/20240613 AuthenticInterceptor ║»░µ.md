```java
package oarlp.common.interceptor;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.interfaces.DecodedJWT;

import egovframework.rte.fdl.property.EgovPropertyService;
import oarlp.common.Constant;
import oarlp.common.util.AES256Cipher;
import oarlp.common.util.CommonUtil;
import oarlp.web.dao.CommonDAO;
import oarlp.web.dto.UserDTO;

/**
 * 인증여부 체크 인터셉터
 * @Class Name  : AuthenticInterceptor.java
 * @author KMYU
 * @since 2017. 10. 19.
 * @version 1.0
 * @see
 * 
 * <pre>
 *  수정일			수정자		수정내용
 *  -------------	---------	-------------------------------
 *  2017. 10. 19.   KMYU        최초생성
 * 
 * </pre>
 */
@Component
public class AuthenticInterceptor extends HandlerInterceptorAdapter {
	private static Logger log = LoggerFactory.getLogger(AuthenticInterceptor.class);
	
	@Autowired
	private CommonDAO dao;
	
	@Autowired
    EgovPropertyService globalProperties;
	
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
		
		Map<String,Object> insertMap = new HashMap<String,Object>();
		String _uid 		= request.getParameter("_uid");
		String messagePage 	= "/message.do";
		String errorType	= ""; // 1:로그인필요, 2:사용권한 없음
		String loginPage 	= globalProperties.getString("ldap.gisportallogin")+"?_r_url="+globalProperties.getString("ldap.oarlpmainpage");
		String ip = request.getRemoteAddr();
     	String browserDetails  =   request.getHeader("User-Agent");
        String userAgent       =   browserDetails;
        String user            =   userAgent.toLowerCase();
        String browser = "";
        
        String uri = request.getScheme() + "://" +   // "http" + "://
                request.getServerName() +       // "myhost"
                ":" +                           // ":"
                request.getServerPort() +       // "8080"
                request.getRequestURI();
        
        String SECRET_KEY = "jiga"; // jwt secret key
        String TOKEN_NAME = "jigaToken";
        Boolean userState = false;
      //===============Browser===========================
        if (user.contains("msie"))
        {
            String substring=userAgent.substring(userAgent.indexOf("MSIE")).split(";")[0];
            browser=substring.split(" ")[0].replace("MSIE", "IE")+"-"+substring.split(" ")[1];
        } else if (user.contains("safari") && user.contains("version"))
        {
            browser=(userAgent.substring(userAgent.indexOf("Safari")).split(" ")[0]).split("/")[0]+"-"+(userAgent.substring(userAgent.indexOf("Version")).split(" ")[0]).split("/")[1];
        } else if ( user.contains("opr") || user.contains("opera"))
        {
            if(user.contains("opera"))
                browser=(userAgent.substring(userAgent.indexOf("Opera")).split(" ")[0]).split("/")[0]+"-"+(userAgent.substring(userAgent.indexOf("Version")).split(" ")[0]).split("/")[1];
            else if(user.contains("opr"))
                browser=((userAgent.substring(userAgent.indexOf("OPR")).split(" ")[0]).replace("/", "-")).replace("OPR", "Opera");
        } else if (user.contains("chrome"))
        {
            browser=(userAgent.substring(userAgent.indexOf("Chrome")).split(" ")[0]).replace("/", "-");
        } else if ((user.indexOf("mozilla/7.0") > -1) || (user.indexOf("netscape6") != -1)  || (user.indexOf("mozilla/4.7") != -1) || (user.indexOf("mozilla/4.78") != -1) || (user.indexOf("mozilla/4.08") != -1) || (user.indexOf("mozilla/3") != -1) )
        {
            //browser=(userAgent.substring(userAgent.indexOf("MSIE")).split(" ")[0]).replace("/", "-");
            browser = "Netscape-?";

        } else if (user.contains("firefox"))
        {
            browser=(userAgent.substring(userAgent.indexOf("Firefox")).split(" ")[0]).replace("/", "-");
        } else if(user.contains("rv"))
        {
            browser="IE-" + user.substring(user.indexOf("rv") + 3, user.indexOf(")"));
        } else
        {
            browser = "UnKnown, More-Info: "+userAgent;
        }
        
		boolean flag        = true;
		
		// LDAP에서 전송된 사용자 정보 확인
		String userNo 			= "";
		String userLoginTime 	= "";
		
		// 세션 정보 확인
		UserDTO userVo = (UserDTO)request.getSession().getAttribute(Constant.SESSION_USER_KEY);
	
		
		// jwt test_____________________________________
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMddHHmmss"); // 시간 포맷 변경
		System.out.println("uid___________________"+_uid);
		Cookie[] cookies = request.getCookies();
		String verifyToken = "";
		if(cookies != null) {
			for (Cookie c:cookies) {
				if(c.getName().equals(TOKEN_NAME)) {
					verifyToken = c.getValue();
					
					

					JWTVerifier verifier = JWT.require(Algorithm.HMAC256(SECRET_KEY))
					                        .withIssuer("auth0")
					                        .build();
					
					try {
						DecodedJWT jwt = verifier.verify(verifyToken);
												
						DecodedJWT decodedJwt = JWT.decode(verifyToken);
	//					String issuer = decodedJwt.getIssuer();
//						String userNumber = decodedJwt.getSubject();
						Date expiresAt = decodedJwt.getExpiresAt();
						Date currentDate = new Date(System.currentTimeMillis());
						
						System.out.println("만료 시간"+ simpleDateFormat.format(expiresAt)+ "현재시간"+ simpleDateFormat.format(currentDate));
						
						if(currentDate.before(expiresAt)) {
							// ok
							userState = true;
						}else {
							// 토큰 만료됨
							userState = false;
						}
						
					} catch(Exception e) {
						// 잘못된 토큰 
						log.error("token error", e);
						userState = false;
					}
				}
			}
		}


		// ________________________________________ jwt test

		if(userVo == null) {
			log.debug("=== 세션 없음");
			//-----------------------------------------------------------------------------------------------------
			// 지가심사 세션 정보가 없으면
			//-----------------------------------------------------------------------------------------------------
			
			if(_uid != null || userState == true) {
				// 포털 시스템에서 넘어 왔을 경우
//				String userInfo = AES256Cipher.AES_Decode(_uid, globalProperties.getString("ldap.aes256decodekey"));
//				String [] temp 	= userInfo.split("\\|");
				
//				userNo 			= temp[0];
//				userLoginTime 	= temp[1];

				
				// user info init test ____________________________________________________________________________
				if(_uid == null && userState == true) {
					DecodedJWT decodedJwt = JWT.decode(verifyToken);
					String userNumber = decodedJwt.getSubject();
					Date expiresAt = decodedJwt.getExpiresAt();
					
					userNo 			= userNumber; // 변경
					userLoginTime 	= simpleDateFormat.format(expiresAt); // 변경
					
				} else {
					String userInfo = AES256Cipher.AES_Decode(_uid, globalProperties.getString("ldap.aes256decodekey"));
					String [] temp 	= userInfo.split("\\|");
					userNo 			= temp[0];
					userLoginTime 	= temp[1];
				}
				
				System.out.println("userInfo" + userNo + " " + userLoginTime);

				// ______________________________________________________________user info init test
					
				

				if(!"".equals(userNo)) {
//					if(CommonUtil.getIntervalSec(userLoginTime) <= globalProperties.getInt("ldap.checkTimeSec")) {
//						JSONObject ldapJson = LdapUtil.checkLdapAuth(globalProperties.getString("ldap.checkurl"), userNo);
//						String result       = (String)ldapJson.get("result");
//						
//						if(result != null && "S000".equals(result)) {
//							System.out.println("----------------------------------------------------");
//							System.out.println(result);
//							JSONObject data = (JSONObject) ldapJson.get("data");
//							userNo = CommonUtil.parseString(data.get("cn").toString(), "");
//						}
//					}
					
					Map<String,Object> paramMap = new HashMap<String,Object>();
					paramMap.put("user_no", userNo);
					
					List<Map<String,Object>> userList = dao.userInfo(paramMap);
					int userCnt = userList.size();
					
					if(userCnt > 0) {
						UserDTO vo = new UserDTO();
						Map<String,Object> data = userList.get(0);
						
						vo.setUserNo(CommonUtil.parseString(data.get("user_no"), ""));
						vo.setUserNm(CommonUtil.parseString(data.get("user_nm"), ""));
						vo.setUserDeptNm(CommonUtil.parseString(data.get("depart_nm"), ""));
						vo.setUserAuth(CommonUtil.parseString(data.get("auth_cd"), ""));
						
						
						// 토큰 등록 test__________________________________________________
						
						Date expirationDate  = new Date(System.currentTimeMillis() + 30 * 60 * 1000);
												
						System.out.println("만료 : "+expirationDate);
						
						// 토큰생성
						String token = JWT.create()
						                .withIssuer("auth0")
						                .withSubject(vo.getUserNo())
						                .withExpiresAt(expirationDate) 
						                .sign(Algorithm.HMAC256(SECRET_KEY));
						
						// 기존 쿠키 삭제 
						if(cookies != null) {
							for (Cookie c:cookies) {
								if(c.getName().equals(TOKEN_NAME)) {
									System.out.println(c.getName());
									System.out.println(c.getValue());
									Cookie prevCookie = new Cookie(TOKEN_NAME, null);
									prevCookie.setPath("/");
									prevCookie.setMaxAge(0);
									response.addCookie(prevCookie);
								}
							}
						}
						
						// 쿠키에 토큰 등록
						Cookie cookie = new Cookie(TOKEN_NAME, token);
						cookie.setPath("/");
						response.addCookie(cookie);

						userState = true; // 유저 로그인 체크
						
						System.out.println("vo1"+ vo.getUserNo()+"usernm : "+vo.getUserNm()+"userDeptNm"+ vo.getUserDeptNm() + "userAuth : "+vo.getUserAuth());
						
						// _________________________________________________토큰 등록 test
						
						// 사용자 세션 생성
						request.getSession().setAttribute(Constant.SESSION_USER_KEY, vo);
						flag = true;
					} else {
						// 지가심사 권한 없음
						errorType = UserDTO.USER_ERR_TP2;
						flag = false;
					}
				}
				// 현재시간과 60초 차이나는 경우
				if(CommonUtil.getIntervalSec(userLoginTime) >= 60) {
					errorType = UserDTO.USER_ERR_TP1;
					flag = false; 
				}
			} else {
				// 세션도 없고 포털을 통해서 온게 아니므로 로그인페이지로 이동해야 함
				errorType = UserDTO.USER_ERR_TP1;
				flag = false;
			}
		} else {
			log.debug("=== 세션 있음");
			
			//-----------------------------------------------------------------------------------------------------
			// 지가심사 세션 정보가 있으면
			//-----------------------------------------------------------------------------------------------------
			
			if(_uid != null || userState == true) {                             
				// 포털 시스템에서 넘어 왔을 경우
//				String userInfo = AES256Cipher.AES_Decode(_uid, globalProperties.getString("ldap.aes256decodekey"));
//				String [] temp 	= userInfo.split("\\|");
				
//				userNo 			= temp[0];
//				userLoginTime 	= temp[1];
				
				// user info init test_____________________________________________________
				if(_uid == null && userState == true) {
					DecodedJWT decodedJwt = JWT.decode(verifyToken);
					String userNumber = decodedJwt.getSubject();
					Date expiresAt = decodedJwt.getExpiresAt();
					
					userNo 			= userNumber; // 변경
					userLoginTime 	= simpleDateFormat.format(expiresAt); // 포맷 변경 후 초기화 
					
				} else {
					String userInfo = AES256Cipher.AES_Decode(_uid, globalProperties.getString("ldap.aes256decodekey"));
					String [] temp 	= userInfo.split("\\|");
					userNo 			= temp[0];
					userLoginTime 	= temp[1];
				}
				
				System.out.println("userInfo" + userNo + " " + userLoginTime);
				// ______________________________________________________________user info init test
				
				
				if(!"".equals(userNo)) {
//					if(CommonUtil.getIntervalSec(userLoginTime) <= globalProperties.getInt("ldap.checkTimeSec")) {
//						JSONObject ldapJson = LdapUtil.checkLdapAuth(globalProperties.getString("ldap.checkurl"), userNo);
//						String result       = (String)ldapJson.get("result");
//						
//						if(result != null && "S000".equals(result)) {
//							System.out.println("----------------------------------------------------");
//							System.out.println(result);
//							JSONObject data = (JSONObject) ldapJson.get("data");
//							userNo = CommonUtil.parseString(data.get("cn").toString(), "");
//						}
//					}
					
					Map<String,Object> paramMap = new HashMap<String,Object>();
					paramMap.put("user_no", userNo);
					
					List<Map<String,Object>> userList = dao.userInfo(paramMap);
					int userCnt = userList.size();
					
					if(userCnt > 0) {
						UserDTO vo = new UserDTO();
						Map<String,Object> data = userList.get(0);
						
						vo.setUserNo(CommonUtil.parseString(data.get("user_no"), ""));
						vo.setUserNm(CommonUtil.parseString(data.get("user_nm"), ""));
						vo.setUserDeptNm(CommonUtil.parseString(data.get("depart_nm"), ""));
						vo.setUserAuth(CommonUtil.parseString(data.get("auth_cd"), ""));
						
						
// 						토큰 등록 test__________________________________________________
						
						Date expirationDate  = new Date(System.currentTimeMillis() + 30 * 60 * 1000);
												
						System.out.println("만료 : "+expirationDate);
						
						// 토큰생성
						String token = JWT.create()
						                .withIssuer("auth0")
						                .withSubject(vo.getUserNo())
						                .withExpiresAt(expirationDate) 
						                .sign(Algorithm.HMAC256(SECRET_KEY));
						
						// 기존 쿠키 삭제 
						if(cookies != null) {
							for (Cookie c:cookies) {
								if(c.getName().equals(TOKEN_NAME)) {
									System.out.println(c.getName());
									System.out.println(c.getValue());
									Cookie prevCookie = new Cookie(TOKEN_NAME, null);
									prevCookie.setPath("/");
									prevCookie.setMaxAge(0);
									response.addCookie(prevCookie);
								}
							}
						}
						
						// 쿠키에 토큰 등록
						Cookie cookie = new Cookie(TOKEN_NAME, token);
						cookie.setPath("/");
						response.addCookie(cookie);

						userState = true; // 유저 로그인 체크
						
						
						
						
						System.out.println("vo2"+ vo.getUserNo()+"usernm : "+vo.getUserNm()+"userDeptNm"+ vo.getUserDeptNm() + "userAuth : "+vo.getUserAuth());
//						 _________________________________________________토큰 등록 test
						
						// 사용자 세션 생성
						request.getSession().setAttribute(Constant.SESSION_USER_KEY, vo);
						flag = true;
					} else {
						// 지가심사 권한 없음
						errorType = UserDTO.USER_ERR_TP2;
						flag = false;
					}
				}
				// 현재시간과 60초 차이나는 경우
				if(CommonUtil.getIntervalSec(userLoginTime) >= 60) {
					errorType = UserDTO.USER_ERR_TP1;
					flag = false; 
				}
			} else {
				flag = true;
			}
		}
		// test__________________________________
		flag = true;
		// _________________________________test
		if(!flag) {
			String requestedWith = request.getHeader("X-Requested-With");
			
			// 세션 초기화
			request.getSession().removeAttribute(Constant.SESSION_USER_KEY);
			
			if(requestedWith == null || !"XMLHttpRequest".equals(requestedWith)) {
				// 인증 실패시 페이지 이동 (페이지 이동)
				request.setAttribute("errorType", 	errorType);
				request.setAttribute("loginPage", 	loginPage);
				request.setAttribute("userNo", 		userNo);
				
				if(errorType == "1") {
					response.sendRedirect("https://dev-portal.gis.lh.or.kr/user/login?_r_url=http://172.23.187.110:8089/"); // 로컬
					//response.sendRedirect("https://portal.gis.lh.or.kr/user/login?_r_url=http://172.23.187.46:9080/"); // 개발
//					response.sendRedirect("https://portal.gis.lh.or.kr/user/login?_r_url=http://jiga.gis.lh.or.kr"); // 운영
				}else {
					RequestDispatcher dispatcher = request.getServletContext().getRequestDispatcher(messagePage);
					dispatcher.forward(request, response);
				}
				
			} else {
				// ajax 요청
				response.setStatus(440);
				response.getWriter().write("세션이 만료되었습니다.\nLH GIS DATA PORTAL 로그인이 필요합니다.");
				response.getWriter().flush();
				response.getWriter().close();
			}
			
		} else {
			if(userNo != "" && ip !="" && browser !="" && userLoginTime !="" && !StringUtils.equals(ip, "0:0:0:0:0:0:0:1") && !StringUtils.equals(ip, "127.0.0.1")) {
				insertMap.put("user_no", userNo);
				insertMap.put("acs_ip", ip);
				insertMap.put("fct_nm", "지가정보 시스템 접속");
				insertMap.put("fct_url", uri);
				dao.insertWebLog(insertMap);
			}
		}
		
		int sessionTimeout = request.getSession().getMaxInactiveInterval(); // 초 단위
		request.setAttribute("sessionTimeout", sessionTimeout);
		System.out.println("세션 타임아웃 시간"+ sessionTimeout);
		// test____________________________________
		flag = true;
		// ___________________________________test
		return flag;
	}
	
}

```